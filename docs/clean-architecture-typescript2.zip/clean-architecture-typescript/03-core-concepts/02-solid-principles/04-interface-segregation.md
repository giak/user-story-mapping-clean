# Principe de Ségrégation des Interfaces

## Table des matières

## Introduction

## Contenu principal

## Conclusion

## Références
