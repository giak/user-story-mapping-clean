# Pattern Adaptateur

## Table des matières

## Introduction

## Contenu principal

## Conclusion

## Références
