# Pattern Agrégat

## Table des matières

## Introduction

## Contenu principal

## Conclusion

## Références
